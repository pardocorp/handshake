# Link Next

This is a Next.js app.

## Getting started

This is a [Next.js](https://nextjs.org/) project that you can deploy in your own Vercel or cloud.

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Deployment

`vercel deploy`

Go to [Next.js deployment documentation](https://nextjs.org/docs/deployment) for more details.
