# Reporting Security Issues

The Fiber team and community take security bugs in Handshake seriously. We
appreciate your efforts to responsibly disclose your findings, and will make
every effort to acknowledge your contributions.

If you have any security concerns or believe you have uncovered a vulnerability,
contact us at [security@fiber.dev](mailto:security@fiber.dev)
