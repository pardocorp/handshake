# handshake

## 1.2.0

- Added support for Faire.

## 0.1.6

- Added support for Monday.

## 0.1.5

- Fixed Salesforce connector by replacing `next-auth`'s with our own.

## 0.1.4

- Added 100 other providers.
